﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Aldente.Services
{
    public static class Constan
    {
        public const string ClaimTenantId = "TenantId";
    }
}
